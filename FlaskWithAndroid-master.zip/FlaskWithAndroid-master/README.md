# FlaskWithAndroid

Python Flask framework as backend to Android app, refer my [blog](https://medium.com/audhil/handmade-backend-for-android-app-using-python-flask-framework-b173ba2bb3aa) for more info. Cheers!!!


<p align="center">
  <img src="https://raw.githubusercontent.com/Audhil/FlaskWithAndroid/master/gif/flask_with_Android.gif" width="250" height="450">
</p>
